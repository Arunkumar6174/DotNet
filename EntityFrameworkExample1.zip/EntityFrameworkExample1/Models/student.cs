﻿namespace EntityFrameworkExample1.Models
{
    public class student
    {
        public int studentid { get; set; }
        public string name { get; set; }
        public int age { get; set; }
    }
}
