﻿namespace EntityFrameworkExample1.Models
{
    public class teacher
    {
        public int teacherid { get; set; }
        public string teachername { get; set; }
        public int age { get; set; }
    }
}
